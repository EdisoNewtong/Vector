#include <stdio.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>

#include <sys/socket.h>

#include <string.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include <time.h>

#define MAX_RECEIV 1024
#define MAX_VISITORS 1024
#define SRV_PORT 9871

//
// Server Program
//

int main(int argc, char* argv[])
{
	int cnt = atoi(argc>=2 ? argv[1] : "123");
	printf("cnt = %d\n",cnt);

	int listenfd = 0;
	int connectedfd = 0;
	struct sockaddr_in servaddr;
	struct sockaddr_in visited_client_addr;
	char read_buffer[MAX_RECEIV] = { 0 };
	char sended_buff[MAX_RECEIV] = { 0 };
	char visitor_ip_str[MAX_RECEIV] = { 0 };
	time_t ticks = 0;
	int iret = 0;
	socklen_t visitor_sock_len = 0;

	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if( listenfd == -1) {
		printf("create socket Failed\n");
		return -1;
	}
	memset( &servaddr, 0, sizeof(servaddr) );
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	// printf("port = %d | %d\n",SRV_PORT,ntohs(SRV_PORT) );
	servaddr.sin_port = htons(SRV_PORT);	// 13是给请求主机发送日期和时间   , > 1024 是给可以是非系统

	iret = bind(listenfd,(struct sockaddr*)&servaddr, sizeof(servaddr) );
	if( iret !=0 ) {
		printf("bind Failed\n");
		return -1;
	}

	iret = listen(listenfd,MAX_VISITORS);
	if( iret!=0 ) {
		printf("listen Failed\n");
		return -1;
	}

	for( ; ; ) 
	{

		// const char *
		// inet_ntop(int af, const void * restrict src, char * restrict dst,
		// socklen_t size);
	 
		memset(&visited_client_addr, 0 , sizeof(visited_client_addr) );
        // int
        // accept(int socket, struct sockaddr *restrict address,
	    // socklen_t *restrict address_len);
		//
		// Notice That, although the accept(...) 3rd arg is a pointer (not a return pointer), 
		// but it need to set a correct value for the socklen_t;
		// visitor_sock_len = 0; // !!!! Error  !!!
		//
		visitor_sock_len = sizeof(visited_client_addr);
		//
		// get the client computer's Ip
		//
		connectedfd = accept(listenfd,(struct sockaddr*)&visited_client_addr, &visitor_sock_len );
		if( connectedfd < 0 ) 
		{
			printf("accept Failed\n");
			break;
		}

		// else
		//visited_client_addr
		printf("one visitor come in\n");
		printf("visited ip : %s:%d\n", inet_ntop(AF_INET, &visited_client_addr.sin_addr, visitor_ip_str, visitor_sock_len), ntohs(visited_client_addr.sin_port ) );
		int times = 0;
		while(1){
			++times;
			memset(read_buffer,MAX_RECEIV,0);
			int n = read(connectedfd,read_buffer,MAX_RECEIV);
			read_buffer[n] = 0;
			if( n > 0 ) {
				printf("%d. read %d , msg : %s\n",times,n,read_buffer);
			}
		}

		// ticks = time(NULL);
		// snprintf(sended_buff, sizeof(sended_buff), "%.24s\r\n" , ctime(&ticks) );
		// for(int i = 0; i < cnt; ++i) {
		// 	write(connectedfd, sended_buff, strlen(sended_buff) );
		// }

		// close(connectedfd);
	}

	return 0;
}



