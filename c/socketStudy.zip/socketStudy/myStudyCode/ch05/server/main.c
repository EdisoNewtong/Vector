
#include <stdio.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <stdlib.h>

#include <sys/socket.h>

#include <string.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include <time.h>

#define MAX_RECEIV 1024
#define MAX_VISITORS 1024

#define SRV_PORT 9877


//
// Server Program
//
void str_echo(int sockfd)
{
	ssize_t n = 0;
	char buf[MAX_RECEIV] = { 0 };
// again:
	while( (n = read(sockfd, buf, MAX_RECEIV)) > 0 ) {
		printf("read data from client done , buf = %s",buf);
		// for(int i = 0; i < n; ++i) {
		// 	printf("buf[%d] = %c , 0x%x\n",i,buf[i],(int)(buf[i]));
		// }
		// printf("Send back to client\n");

		//
		// Test Only , Echo Backup String apend  ' 123'
		//
		// buf[n-1] = ' '; 
		// buf[n] = '1'; 
		// buf[n+1] = '2'; 
		// buf[n+2] = '3'; 
		// buf[n+3] = 0; 
		// write(sockfd,buf,n+4);

		write(sockfd,buf,n);
	}

	// if( n < 0 && errno == EINTR) {
	// 	goto again;
	// } else if( n < 0 ) {
	// 	printf("str_echo read error");
	// }

	printf("str_echo return\n");
}

int main(int argc, char* argv[])
{
	// printf("main started\n");
	pid_t childpid;
	int listenfd = 0;
	int connectedfd = 0;
	struct sockaddr_in servaddr;
	struct sockaddr_in visited_client_addr;
	// char sended_buff[MAX_RECEIV] = { 0 };
	char visitor_ip_str[MAX_RECEIV] = { 0 };
	// time_t ticks = 0;
	int iret = 0;
	socklen_t visitor_sock_len = 0;

	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if( listenfd == -1) {
		printf("create socket Failed\n");
		return -1;
	}
	memset( &servaddr, 0, sizeof(servaddr) );
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SRV_PORT);

	iret = bind(listenfd,(struct sockaddr*)&servaddr, sizeof(servaddr) );
	if( iret !=0 ) {
		printf("bind Failed\n");
		return -1;
	}

	iret = listen(listenfd,MAX_VISITORS);
	if( iret!=0 ) {
		printf("listen Failed\n");
		return -1;
	}

	for( ; ; ) 
	{

		// const char *
		// inet_ntop(int af, const void * restrict src, char * restrict dst,
		// socklen_t size);
	 
		memset(&visited_client_addr, 0 , sizeof(visited_client_addr) );
        // int
        // accept(int socket, struct sockaddr *restrict address,
	    // socklen_t *restrict address_len);
		//
		// Notice That, although the accept(...) 3rd arg is a pointer (not a return pointer), 
		// but it need to set a correct value for the socklen_t;
		// visitor_sock_len = 0; // !!!! Error  !!!
		//
		visitor_sock_len = sizeof(visited_client_addr);
		//
		// get the client computer's Ip
		//
		connectedfd = accept(listenfd,(struct sockaddr*)&visited_client_addr, &visitor_sock_len );

		if( connectedfd < 0 ) {
			printf("accept Failed\n");
			break;
		}

		if( (childpid = fork()) == 0 ) {
			// printf("fork() end In if\n");
			close(listenfd);

			printf("one visitor come in\n");
			printf("visited ip : %s:%d\n", inet_ntop(AF_INET, &visited_client_addr.sin_addr, visitor_ip_str, visitor_sock_len), ntohs(visited_client_addr.sin_port ) );

			str_echo(connectedfd);
			exit(0);
		}

		close(connectedfd);
	}

	return 0;
}



