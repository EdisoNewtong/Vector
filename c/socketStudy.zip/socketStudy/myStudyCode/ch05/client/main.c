
#include <stdio.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <stdlib.h>

#include <sys/socket.h>

#include <string.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX_RECEIV 1024

#define SRV_PORT 9877

// using namespace std;


ssize_t readline(int sockfd,char* buf,size_t maxChar)
{
	ssize_t total = 0;
	char ch = 0;
	int read_cnt = 0;

	for(int i = 0; i < maxChar; ++i) {
		read_cnt = read(sockfd,&ch,sizeof(ch) );
		// printf("read_cnt = %d ,ch = %c\n",read_cnt, ch);
		if( read_cnt < 0 ) {
			printf("read(...) failed \n");
			total = -1;
			break;
		} else if( read_cnt == 0 ) {
			printf("read_cnt == 0\n");
			total = 0;
			break;
		} else {
			if(ch != '\n' ) {
				*buf++ = ch;
				++total;
			} else {
				// finially meet  '\n'
				// printf("Meet \\n\n break");
				*buf = 0;
				break;
			}
		}
	}

	return total;
}
//
// Client Program
//
void sendinput(FILE* fp,int sockfd)
{
	printf("Please input something : \n");
	char sendline[MAX_RECEIV] = { 0 };
	char recvline[MAX_RECEIV] = { 0 };
	while( fgets(sendline,MAX_RECEIV,fp) !=NULL ) {
		// printf("recvline = %s\n",sendline);
		write(sockfd, sendline, strlen(sendline));

		// printf("Now Start recvline from server\n");
		if( read(sockfd,recvline,MAX_RECEIV) <= 0 ) {
		// if( readline(sockfd,recvline, MAX_RECEIV) <= 0 ) {
			printf("server terminated prematurely\n");
		} else {
			printf("recvline from server Echo Finished!! \nrecvline = %s\n",recvline);
			printf("Please input something : \n");
			// break;
		}
	}

	// printf("recvline from server Echo Finished!! \n recvline = %s\n",recvline);
}

int main(int argc, char* argv[])
{
	if( argc!=2 ) {
		printf("argc != 2\n");
		return -1;
	}

	int socketfd = 0;
	struct sockaddr_in servaddr;
	struct sockaddr_in cal_servaddr;
	int iret = 0;
	// int n = 0;
	// char receivered[MAX_RECEIV] = { 0 };
	char visitor_ip_str[MAX_RECEIV] = { 0 };

	// AF_INET == PF_INET
	socketfd = socket(PF_INET, SOCK_STREAM, 0);	// in <sys/socket.h>
	if( socketfd == -1) {
		printf("create socket Failed\n");
		return -1;
	}

	memset(&servaddr, 0 , sizeof(servaddr) );	// in <string.h>
	servaddr.sin_family = PF_INET;
	servaddr.sin_port = htons(SRV_PORT);
	iret = inet_pton(PF_INET, /*AF_INET,*/ argv[1], &servaddr.sin_addr);	// in <arpa/inet.h> && <netinet/in.h>
	if( iret != 1) {
		printf("inet_pton call failed\n");
		return -1;
	}
	// servaddr.sin_addr.s_addr   32bit  | 4 bytes number

	iret = connect(socketfd,(struct sockaddr*)&servaddr, sizeof(servaddr) );
	if( iret != 0 ) {
		printf("connect failed\n");
		return -1;
	}

	memset(&cal_servaddr, 0 , sizeof(cal_servaddr) );	// in <string.h>
	socklen_t getlen = sizeof(cal_servaddr);
	socklen_t getlen2 = getlen;
	iret = getsockname(socketfd, ((struct sockaddr*)&cal_servaddr), &getlen);
	printf("System-Self Alloc IP ->  ip = %s , port = %d.\n", inet_ntop(AF_INET, &cal_servaddr.sin_addr, visitor_ip_str, getlen2), ntohs(cal_servaddr.sin_port ) );
	
	sendinput(stdin,socketfd);
	// printf("readed_cnt = %d\n",readed_cnt);
	
	return 0;
}



