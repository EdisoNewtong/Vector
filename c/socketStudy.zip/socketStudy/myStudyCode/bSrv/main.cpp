#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>

#include <sys/socket.h>

#include <string.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#include <time.h>
#include <string>
#include <vector>

using namespace std;

#define MAX_BUFFER_SIZE 1024
#define MAX_VISITORS 1024
#define SRV_PORT	10000

#define ALL_PLAYER_NUMBER 5

void makeMsgComplete(int msgId,char processedBuf[],const char* gettedbuf)
{
	memset(processedBuf,0,1024);
	snprintf(processedBuf,1024,"%d:%s#",msgId,gettedbuf);
}

//
// Server Program
//

pthread_mutex_t locker_mutex = PTHREAD_MUTEX_INITIALIZER;

static void* Data_handle(void * arg);
void parseReadedMsg(const string& readedStr,string& incompleteStr,vector<string>& msglist);

struct Member
{
	float x;
	float y;
	float rotation;
};

struct playerInfo
{
	int  conn_fd;
	string incompletestr;

	float visibleWidth;
	float visibleHeight;

	struct Member all_player_list[ALL_PLAYER_NUMBER];
};

struct DataPair
{
	struct playerInfo player[2];

	void init()
	{
		for(int i = 0; i < 2; ++i) {
			player[i].conn_fd = 0;
			player[i].incompletestr = "";

			player[i].visibleWidth = 0.0f;
			player[i].visibleHeight = 0.0f;

			for(int j = 0; j < ALL_PLAYER_NUMBER; ++j) {
				player[i].all_player_list[j].x = 0.0f;
				player[i].all_player_list[j].y = 0.0f;
				player[i].all_player_list[j].rotation = 0.0f;
			}
		}
	}

	DataPair() { init(); }
	virtual ~DataPair() { init(); }
};


struct FullData
{
	vector<DataPair*> G_2_PLAYERS_PAIR_LIST;
};

static struct FullData G_ALL_DATA;

void initGData()
{
	G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.clear();
}

pair<int,bool> getCurrentPairIndex()
{
	// second = false	--> 
	// second = true	--> means need to new DataPair
	if( G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.empty() ) {
		return make_pair(0,true);
	} else {
		int idx = 0;
		bool need_create_new = false;
		for(vector<DataPair*>::iterator it = G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.begin(); it!=G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.end(); ++it) {
			DataPair* pr = *it;
			if( pr == NULL ) {
				// jump NULL pointer
				++idx;
			} else {
				// pr!=NULL
				if( pr->player[0].conn_fd == 0 ) {
					// set host here
					need_create_new = false;
					break;
				} else {
					if( pr->player[1].conn_fd == 0 ) {
						// set guest here
						need_create_new = false;
					} else {
						// [0].conn_fd!=0 && [1].conn_fd!=0
						idx += 1;
						need_create_new = true;
						break;
					}
				}
			}
		}
		
		if( idx >= (int)(G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.size()) ){
			need_create_new = true;
		}

		return make_pair(idx,need_create_new); 
	}
}

pair<bool,pair<int,int> > find_index_of_fd(int fd)
{
	int player1_2 = -1;
	int vecIdx = -1;
	bool finded = false;
	for(vector<DataPair*>::iterator it = G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.begin(); it!=G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.end(); ++it) {
		DataPair* pr = *it;
		if( pr!=NULL ) {
			if( pr->player[0].conn_fd == fd) {
				finded = true;
				vecIdx = (it - G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.begin());
				player1_2 = 0;
				break;
			} else if( pr->player[1].conn_fd == fd) {
				finded = true;
				vecIdx = (it - G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.begin());
				player1_2 = 1;
				break;
			}
		}
	}

	// second.first = vector's index
	// second.second = player's index 0/1
	return make_pair( finded, make_pair(vecIdx,player1_2));
}



void addGData(int fd)
{
	pair<int,bool> ret = getCurrentPairIndex();
	if( ret.second ) {
		// need push_back new
		DataPair* new_pr = new DataPair;
		new_pr->player[0].conn_fd = fd;
		G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.push_back(new_pr);
		printf("Add new-pair : VecIdx = %ld , [0] -> fd = %d\n",G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.size() - 1, fd);
	} else {
		// do not need to add new element
		// printf("ret.first = %d\n",ret.first);
		DataPair* cur_pr = G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.at(ret.first);
		if( cur_pr!=NULL) {
			if( cur_pr->player[0].conn_fd == 0){
				printf("Logic Error !!!!!! set vecIdx = %d , player[0].fd = %d\n",ret.first, fd);
				cur_pr->player[0].conn_fd = fd;
			} else if( cur_pr->player[1].conn_fd == 0){
				printf("set vecIdx = %d , player[1].fd = %d\n",ret.first, fd);
				cur_pr->player[1].conn_fd = fd;
			}
		}
	}
}

int responseToClient(const char* readed,int fd);

int main(int argc, char* argv[])
{
	initGData();

	int listenfd = 0;
	int connectedfd = 0;
	struct sockaddr_in servaddr;
	struct sockaddr_in visited_client_addr;
	char sended_buff[MAX_BUFFER_SIZE] = { 0 };
	char visitor_ip_str[MAX_BUFFER_SIZE] = { 0 };
	time_t ticks = 0;
	int iret = 0;
	socklen_t visitor_sock_len = 0;

	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if( listenfd == -1) {
		cout << "create socket Failed" << endl;
		return -1;
	}
	memset( &servaddr, 0, sizeof(servaddr) );
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	// printf("port = %d | %d\n",SRV_PORT,ntohs(SRV_PORT) );
	servaddr.sin_port = htons(SRV_PORT);	// 13是给请求主机发送日期和时间   , > 1024 是给可以是非系统

	bind(listenfd,(struct sockaddr*)&servaddr, sizeof(servaddr) );
	// if( iret1 !=0 ) {
	// 	cout << "bind Failed" << endl;
	// 	return -1;
	// }

	iret = listen(listenfd,MAX_VISITORS);
	if( iret!=0 ) {
		cout << "listen Failed" << endl;
		return -1;
	}

	printf("wait for client ...\n");

	int visitedCnt = 0;
	for( ; ; )
	{

		// const char *
		// inet_ntop(int af, const void * restrict src, char * restrict dst,
		// socklen_t size);

		memset(&visited_client_addr, 0 , sizeof(visited_client_addr) );
        // int
        // accept(int socket, struct sockaddr *restrict address,
	    // socklen_t *restrict address_len);
		//
		// Notice That, although the accept(...) 3rd arg is a pointer (not a return pointer),
		// but it need to set a correct value for the socklen_t;
		// visitor_sock_len = 0; // !!!! Error  !!!
		//
		visitor_sock_len = sizeof(visited_client_addr);
		//
		// get the client computer's Ip
		//
		// if( connectedfd == 0 ) {
		connectedfd = accept(listenfd,(struct sockaddr*)&visited_client_addr, &visitor_sock_len );
		if( connectedfd <= 0 ) {
			cout << "accept Failed" << endl;
			break;
		}
		// }

		// else
		//visited_client_addr
		++visitedCnt;
		const char* visited_ip = inet_ntop(AF_INET, &visited_client_addr.sin_addr, visitor_ip_str, visitor_sock_len);
		int visited_port = ntohs(visited_client_addr.sin_port );
		printf("visitor %d comes , fd = %d, ip : %s:%d\n",visitedCnt, connectedfd, visited_ip, visited_port );
		addGData(connectedfd);
		// G_WrapData.cur_fd = connectedfd;


		pthread_t thread_id;
		// printf("A new connection occurs!\n");
        if( pthread_create(&thread_id,NULL,Data_handle,(void*)(&connectedfd)) == -1 ) {
            printf("pthread_create error!\n");
            break;                                  //break while loop
        }

		// close(connectedfd);
	}

	return 0;
}

static void* Data_handle(void * arg)
{
	int fd = *((int*)arg);

    int i_recvBytes = 0;
    char data_recv[MAX_BUFFER_SIZE] = { 0 };

    while(1)
    {
        // printf("waiting for request...\n");
        //Reset data.
        memset(data_recv,0,MAX_BUFFER_SIZE);

        i_recvBytes = read(fd,data_recv,MAX_BUFFER_SIZE);
        if(i_recvBytes == 0) {
            // printf("Maybe the client has closed\n");
            break;
        }

        if(i_recvBytes == -1) {
            // fprintf(stderr,"read error!\n");
            break;
        }

		// core code
		data_recv[i_recvBytes] = 0;
		// pthread_mutex_lock(&locker_mutex);
		int retret = responseToClient(data_recv,fd);
		// pthread_mutex_unlock(&locker_mutex);
    }

    // Clear
    printf("fd = %d , terminating current client_connection...\n",fd);
	// Destory the finded pair
	pair<bool,pair<int,int> > findret = find_index_of_fd(fd);
	if( findret.first ) {
		int vecIdx = findret.second.first;
		int playerIdx = findret.second.second;

		vector<DataPair*>::iterator it = G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.begin() + vecIdx;
		DataPair* willDelete = *it;
		if( willDelete!=NULL) {
			if( playerIdx == 0 ) {
				// notify guest
				if( willDelete->player[1].conn_fd!=0 ) {
					printf("notify guest to close , fd = %d\n",willDelete->player[1].conn_fd);
					string oppsiteQuitMsg = "999:OppsiteQuit#";
					write(willDelete->player[1].conn_fd,oppsiteQuitMsg.c_str(), oppsiteQuitMsg.size() );
					// close( willDelete->player[1].conn_fd );
				}
			} else {
				// playerIdx == 1
				// host must online , notify host
				printf("notify Host to close , fd = %d\n",willDelete->player[0].conn_fd);
				string oppsiteQuitMsg = "999:OppsiteQuit#";
				write(willDelete->player[0].conn_fd,oppsiteQuitMsg.c_str(), oppsiteQuitMsg.size() );
				// close( willDelete->player[0].conn_fd );
			}
			
			printf("Destory DataPair vec[ %d ] , player[ %d ] \n", vecIdx, playerIdx);
			// Destory it
			delete willDelete;
			*it = NULL;
		}
	}

	close(fd);
    pthread_exit(NULL);   //terminate calling thread!

	return NULL;
}

void parseReadedMsg(const string& readedStr,string& incompleteStr,vector<string>& msglist)
{
	msglist.clear();

	bool is_incomplete = !incompleteStr.empty();
	bool has_delim = (readedStr.find('#')!=string::npos);
	// bool isComplete = (incomeStr.at(incomeStr.size()-1) == '#');

	if( !has_delim ) {
		// not has #
		// do not send
		incompleteStr += readedStr;
	} else {
		// has #
		string::size_type find_start_pos = 0;
		while(true)
		{
			string::size_type del_pos = readedStr.find('#',find_start_pos);
			if( del_pos!=string::npos) {
				string msg_1 = readedStr.substr(find_start_pos, (del_pos-find_start_pos));
				find_start_pos = del_pos + 1;
				if( is_incomplete ) {
					incompleteStr += msg_1;
					msglist.push_back(incompleteStr);
					incompleteStr = "";
				} else {
					msglist.push_back(msg_1);
				}
			} else {
				string rest_str = readedStr.substr(find_start_pos);
				incompleteStr = rest_str;
				break;
			}
		}
	}

	/*
	if( msglist.empty() ) {
		cout << "No Msg to process" << endl;
		cout << "incompleteStr = " << (incompleteStr.empty() ? string("\"\"") : incompleteStr) << endl;
	} else {
		int cnt = 0;
		for(vector<string>::iterator it = msglist.begin(); it!=msglist.end(); ++it) {
			++cnt;
			cout << cnt << ". " << *it << endl;
		}
		cout << "incompleteStr = " << (incompleteStr.empty() ? string("\"\"") : incompleteStr) << endl;
	}
	*/
}


int responseToClient(const char* readed,int fd)
{
	fprintf(stderr,"\n====================\n");
	fprintf(stderr,"fd=%d , received = %s\n",fd,readed);
	// printf("received , fd = %d , msg = %s\n",fd,readed);

	int self_fd = fd;

	pair<bool, pair<int,int> > find_ret = find_index_of_fd(fd);
	bool hasFinded = find_ret.first;
	if( !hasFinded ) {
		return -1;
	}


	int vecIdx = find_ret.second.first;
	int self_index = find_ret.second.second;
	int oppsite_index = (self_index == 0 ? 1 : 0);
	bool has_oppsite = false;
	DataPair* pr = G_ALL_DATA.G_2_PLAYERS_PAIR_LIST.at(vecIdx);
	if( self_index == 1) {
		has_oppsite = true;
	} else {
		// self_index = 0;
		if( pr!=NULL) {
			has_oppsite = (pr->player[1].conn_fd!=0);
		}
	}

	
	if( pr == NULL ) {
		return -1;
	}

	if ( pr->player[0].conn_fd == 0 ) {
		return -1;
	}

	std::string parseStr = readed;
	vector<string> msgList;
	parseReadedMsg(parseStr, pr->player[self_index].incompletestr,msgList);

	// debug used
	int flag = 1;
	if( flag ) {
		fprintf(stderr,"incompleteStr = %s\n", pr->player[self_index].incompletestr.c_str());
		int cnt = 0;
		for(vector<string>::iterator it = msgList.begin(); it!=msgList.end(); ++it) {
			++cnt;
			fprintf(stderr,"%d. split buf = %s\n",cnt, it->c_str());
			fprintf(stderr,"====================\n");
		}
	}

	int ret = 0;
	for(vector<string>::iterator it = msgList.begin(); it!=msgList.end(); ++it){
		string singleMsg = *it;
		int msgId = 0;
		char msg[MAX_BUFFER_SIZE] = { 0 };
		char send_data[MAX_BUFFER_SIZE] = { 0 };
		
		sscanf(singleMsg.c_str(),"%d:%s",&msgId,msg);

		switch(msgId)
		{
		case 1:	// host / guest
			{
				if( !has_oppsite ) {
					// is host
					string rep = "1:h#";
					// printf("write fd=%d , 1:h\n",self_fd);
					write( self_fd,rep.c_str(), rep.size() );
				} else {
					// is guest
					string rep = "1:g#";
					// printf("write fd=%d , 1:g\n",self_fd);
					write( self_fd,rep.c_str(), rep.size() );

					int oppsite_fd = pr->player[oppsite_index].conn_fd;
					if( oppsite_fd!=-1){
						string op_msg = "1:g_ready#";
						// printf("write fd=%d ,  1:g_ready\n",oppsite_fd);
						write( oppsite_fd,op_msg.c_str(), op_msg.size() );
					}
				}
				ret = 1;
			}
			break;
		case 2:	// move
			{
				if( has_oppsite ){
					int oppsite_fd = pr->player[oppsite_index].conn_fd;
					makeMsgComplete(msgId,send_data,msg);
					// fprintf(stderr,"write fd=%d , %s\n",oppsite_fd,send_data);
					write(oppsite_fd,send_data,strlen(send_data));
				}

				ret = 1;
			}
			break;
		case 3: // visible Size
			{
				ret = 1;
			}
			break;
		case 4:	// pass ball
		case 5:	// shot ball
			{
				if( has_oppsite ){
					int oppsite_fd = pr->player[oppsite_index].conn_fd;
					makeMsgComplete(msgId,send_data,msg);
					fprintf(stderr,"write buf , fd = %d , buf = %s\n",oppsite_fd,send_data);
					write(oppsite_fd ,send_data, strlen(send_data) );
				}

				ret = 1;
			}
			break;
		case 6:
			{				
				if( has_oppsite ){
					int oppsite_fd = pr->player[oppsite_index].conn_fd;
					makeMsgComplete(msgId,send_data,msg);
					fprintf(stderr,"write buf , fd = %d , buf = %s\n",oppsite_fd,send_data);
					// fprintf(stderr,"write fd=%d , %s\n",oppsite_fd,send_data);
					write( oppsite_fd,send_data, strlen(send_data) );
				}

				ret = 1;
			}
			break;
		case 7:
			{
				if( has_oppsite ){
					int oppsite_fd = pr->player[oppsite_index].conn_fd;
					memset(send_data,0,sizeof(send_data));
					snprintf(send_data,sizeof(send_data),"7:%s#",msg);
					fprintf(stderr,"write fd=%d , %s\n",oppsite_fd,send_data);
					//  write( oppsite_fd,send_data, strlen(send_data) );
					write(oppsite_fd,send_data,strlen(send_data));
				}
	
				ret = 1;
			}
			break;
		// case 5:
		// 	{
		// 	}
		// 	break;
		default:
			ret = -1;
			break;
		}
	}

	/// 111
	return ret;
}


