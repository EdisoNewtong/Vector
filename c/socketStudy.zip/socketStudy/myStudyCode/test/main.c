
//
// 以下程序用于获取本地的ip地址
//

#include <string.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>


#define PORT 7778
#define MAXDATASIZE 1024

void getSelfIpFunc1()
{
	printf("use ioctl function \n");
    int inet_sock;
    struct ifreq ifr;
    inet_sock = socket(AF_INET, SOCK_DGRAM, 0); 
    //eth0为接口到名称

    strcpy(ifr.ifr_name, "en0");

    //SIOCGIFADDR标志代表获取接口地址

    if (ioctl(inet_sock, SIOCGIFADDR, &ifr) ==  0) {
        perror("ioctl");
	}

    printf("Self-System ip : | %s | \n", inet_ntoa(((struct sockaddr_in*)&(ifr.ifr_addr))->sin_addr));
}

void getSelfIpFunc2()
{
	printf("use  UDP BROADCAST sendto <-> recvfrom \n");
	struct sockaddr_in user_addr,my_addr;
	char my_ip[MAXDATASIZE];
	int socket_fd;
	int so_broadcast=1;
	char buf[MAXDATASIZE];

	socklen_t size;

	my_addr.sin_family=AF_INET;
	my_addr.sin_port=htons(PORT);
	my_addr.sin_addr.s_addr=inet_addr("255.255.255.255");


	user_addr.sin_family=AF_INET;
	user_addr.sin_port=htons(PORT);
	user_addr.sin_addr.s_addr=htonl(INADDR_ANY);


	if((socket_fd=(socket(AF_INET,SOCK_DGRAM,0)))==-1) {
		perror("socket");
		exit(1);
	}
	setsockopt(socket_fd,SOL_SOCKET,SO_BROADCAST,&so_broadcast,sizeof(so_broadcast));//??socket发送的数据具有广播特性

	if((bind(socket_fd,(struct sockaddr *)&user_addr, sizeof(struct sockaddr)))==-1) {
		perror("bind");
		exit(1);
	}

	strcpy(buf,"broadcast test");
	sendto(socket_fd,buf,strlen(buf),0,(struct sockaddr *)&my_addr,sizeof(my_addr));
	size=sizeof(user_addr);
	recvfrom(socket_fd,buf,MAXDATASIZE,0,(struct sockaddr *)&user_addr,&size);

	strcpy(my_ip,inet_ntoa(user_addr.sin_addr));
	printf("my_ip : | %s | \n",inet_ntoa(user_addr.sin_addr));
}

int main()
{
	char choice = 0;

	while( 1 ) {
		printf("Please choose the method to get Self-System ip : 1/2 ? ");
		choice = getchar();
		// scanf("%c\n",&choice);

		if( choice == '1' ) { 
			getSelfIpFunc1();
			break;
		} else if( choice == '2' ) {
			getSelfIpFunc2();
			break;
		} else {
			printf("Sorry! You must input 1 or 2, please try again.\n");
		}
	}

    return 0;
}




