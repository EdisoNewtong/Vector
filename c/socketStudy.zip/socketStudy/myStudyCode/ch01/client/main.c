
#include <stdio.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>

#include <sys/socket.h>

#include <string.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX_RECEIV 1024
#define SRV_PORT 9871


//
// Client Program
//

int main(int argc, char* argv[])
{
	if( argc!=2 )
	{
		printf("argc != 2\n");
		return -1;
	}

	int socketfd = 0;
	struct sockaddr_in servaddr;
	struct sockaddr_in cal_servaddr;
	int iret = 0;
	int n = 0;
	char receivered[MAX_RECEIV] = { 0 };
	char visitor_ip_str[MAX_RECEIV] = { 0 };

	// AF_INET == PF_INET
	socketfd = socket(PF_INET, SOCK_STREAM, 0);	// in <sys/socket.h>
	if( socketfd == -1) {
		printf("create socket Failed\n");
		return -1;
	}

	memset(&servaddr, 0 , sizeof(servaddr) );	// in <string.h>
	servaddr.sin_family = PF_INET;
	servaddr.sin_port = htons(SRV_PORT);		// 13是给请求主机发送日期和时间   , > 1024 是给可以是非系统
	iret = inet_pton(PF_INET, /*AF_INET,*/ argv[1], &servaddr.sin_addr);	// in <arpa/inet.h> && <netinet/in.h>
	if( iret != 1) {
		printf("inet_pton call failed\n");
		return -1;
	}
	// servaddr.sin_addr.s_addr   32bit  | 4 bytes number

	iret = connect(socketfd,(struct sockaddr*)&servaddr, sizeof(servaddr) );
	if( iret != 0 ) {
		printf("connect failed\n");
		return -1;
	} else {
		printf("connect Successed\n");
	}

	memset(&cal_servaddr, 0 , sizeof(cal_servaddr) );	// in <string.h>
	socklen_t getlen = sizeof(cal_servaddr);
	socklen_t getlen2 = getlen;
	// printf("Pre getlen = %d\n",getlen);
	iret = getsockname(socketfd, ((struct sockaddr*)&cal_servaddr), &getlen);
	printf("System-Self Alloc IP ->  ip = %s , port = %d.\n", inet_ntop(AF_INET, &cal_servaddr.sin_addr, visitor_ip_str, getlen2), ntohs(cal_servaddr.sin_port ) );
	// printf("visitor_ip_str = %s\n", visitor_ip_str);
	// printf("getlen2 = %d\n",getlen2);

	while( (n = read(socketfd, receivered, MAX_RECEIV)) > 0 ) {
		receivered[n] = 0;
		printf("received content :    %s\n", receivered);
		printf("Pressed Any Key to Exit\n" );
		getchar();
	}

	return 0;
}



