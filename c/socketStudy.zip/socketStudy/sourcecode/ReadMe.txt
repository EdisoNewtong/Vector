						<< Unix Network Programming >>

注意:
	运行客户端程序之前，你必须先启动服务器程序

如书中第一章 P6   daytimetcpcli.c 程序中
$ ./daytimetcpcli 127.0.0.1
connect error: Connection refused

会出现这样子的错误

**************************************************
这是因为你没有先启动服务器进程所导致的
**************************************************

$ sudo ./daytimetcpsrv
Then run the
$ ./daytimetcpcli 127.0.0.1
Tue Sep  2 01:12:39 2014		// That's OK


